from src.ui.interfejs_user import InterfejsUzytkownika

if __name__ == '__main__':
    InterfejsUzytkownika().uruchom()